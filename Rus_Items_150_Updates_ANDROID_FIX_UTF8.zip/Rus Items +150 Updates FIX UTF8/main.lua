local EID = RegisterMod( "External Item Descriptions" ,1 );
local itemConfig = Isaac.GetItemConfig()

local _, err = pcall(require, "config")
err = tostring(err)
if not string.match(err, "attempt to call a nil value %(method 'ForceError'%)") then
    if string.match(err, "true") then
        err = "Error: require passed in config"
    end
    Isaac.DebugString(err)
    print(err)
end
  require("descriptions.ab+."..EIDConfig["Language"])

if not __eidItemDescriptions then
  __eidItemDescriptions = {};
end
if not __eidTrinketDescriptions then
  __eidTrinketDescriptions = {};
end
if not __eidCardDescriptions then
  __eidCardDescriptions = {};
end
if not __eidPillDescriptions then
  __eidPillDescriptions = {};
end
if not __eidItemTransformations then
  __eidItemTransformations = {};
end
if not __eidEntityDescriptions then
  __eidEntityDescriptions = {};
end
if not __eidRusItemDescriptions then
__eidRusItemDescriptions = {};
end
if not __eidRusTrinketDescriptions then
__eidRusTrinketDescriptions = {};
end
if not __eidRusCardDescriptions then
__eidRusCardDescriptions = {};
end
if not __eidRusPillDescriptions then
__eidRusPillDescriptions = {};
end
if not __eidRusItemTransformations then
__eidRusItemTransformations = {};
end
if not __eidRusEntityDescriptions then
__eidRusEntityDescriptions = {};
end

function getModDescription(list, id)
if list==__eidItemDescriptions and (__eidRusItemDescriptions) and (__eidRusItemDescriptions[id]) then
return (__eidRusItemDescriptions) and (__eidRusItemDescriptions[id])
elseif list==__eidTrinketDescriptions and (__eidRusTrinketDescriptions) and (__eidRusTrinketDescriptions[id]) then
return (__eidRusTrinketDescriptions) and (__eidRusTrinketDescriptions[id])
elseif list==__eidCardDescriptions and (__eidRusCardDescriptions) and (__eidRusCardDescriptions[id]) then
return (__eidRusCardDescriptions) and (__eidRusCardDescriptions[id])
elseif list==__eidPillDescriptions and (__eidRusPillDescriptions) and (__eidRusPillDescriptions[id]) then
return (__eidRusPillDescriptions) and (__eidRusPillDescriptions[id])
elseif list==__eidItemTransformations and (__eidRusItemTransformations) and (__eidRusItemTransformations[id]) then
return (__eidRusItemTransformations) and (__eidRusItemTransformations[id])
elseif list==__eidEntityDescriptions and (__eidRusEntityDescriptions) and (__eidRusEntityDescriptions[id]) then
return (__eidRusEntityDescriptions) and (__eidRusEntityDescriptions[id])
else 
return (list) and (list[id])
end
end

if EIDConfig["Language"]=="ru_detailed" and EIDConfig["Scale"] > 0.5 then
	EIDConfig["Scale"] = 0.5
end

local IconSprite = Sprite()
IconSprite:Load("gfx/icons.anm2", true)
IconSprite.Scale = Vector(EIDConfig["Scale"],EIDConfig["Scale"])

local ArrowSprite = Sprite()
ArrowSprite:Load("gfx/icons.anm2", true)
ArrowSprite:Play("Arrow",false)

local SacrificeCounter = 1
if EIDConfig["DisplaySacrificeInfo"] then 

function onNewFloor()
	SacrificeCounter = 1
end
EID:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, onNewFloor)

function onDamage(_,entity,_,_,source)
	if Game():GetRoom():GetType()==RoomType.ROOM_SACRIFICE and source.Type==0 then
		if SacrificeCounter<12 then
			SacrificeCounter= SacrificeCounter+1
		end
	end
end
EID:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, onDamage,EntityType.ENTITY_PLAYER)

end


function printDescription(desc)
	local Description = desc[4]
	local temp = EIDConfig["YPosition"]
	local itemTypes= {"null","passive","active","familiar","trinket"}
	local itemType = itemConfig:GetCollectible(desc[1]).Type
	if type(desc[3])=="table" then
	    Description=desc[3][2]
	    desc[3]=desc[3][1]
	elseif desc[4]==nil then
	    Description=desc[3]
	    desc[3]=itemConfig:GetCollectible(desc[1]).Name
	end
	
	if EIDConfig["ShowItemType"] and (itemType ==3 or itemType== 4) then	
		local offsetX = 0
		if not EIDConfig["ShowItemName"]then	offsetX = 5*EIDConfig["Scale"]
			temp = temp+10*EIDConfig["Scale"] 
		end
		IconSprite:Play(itemTypes[itemType])
		IconSprite.Scale = Vector(EIDConfig["Scale"],EIDConfig["Scale"])
		IconSprite:Update()
		IconSprite:Render(Vector(EIDConfig["XPosition"]-3*EIDConfig["Scale"]+offsetX,temp+1*EIDConfig["Scale"]), Vector(0,0), Vector(0,0))
		if itemType ==3 then
			IconSprite:Play(itemConfig:GetCollectible(desc[1]).MaxCharges)
			IconSprite.Scale = Vector(EIDConfig["Scale"],EIDConfig["Scale"])
			IconSprite:Update()
			IconSprite:Render(Vector(EIDConfig["XPosition"]-3*EIDConfig["Scale"]+offsetX,temp+1*EIDConfig["Scale"]), Vector(0,0), Vector(0,0))
		end
		if not EIDConfig["ShowItemName"] then
			temp = temp+10*EIDConfig["Scale"]
		end
	end

	if EIDConfig["ShowItemName"] then
		local offset = 1
		if EIDConfig["ShowItemType"]then	if itemType==3 then  offset = 9 else  offset = 6 end end
		Isaac.RenderScaledText(desc[3], EIDConfig["XPosition"]+offset*EIDConfig["Scale"], temp-4,EIDConfig["Scale"],EIDConfig["Scale"],EIDConfig["ItemNameColor"][1] , EIDConfig["ItemNameColor"][2], EIDConfig["ItemNameColor"][3], EIDConfig["Transparency"])
		temp = temp+10*EIDConfig["Scale"]
	end
	
	

	if not(desc[2]=="0" or desc[2]=="" or desc[2]==nil ) then
		if EIDConfig["TransformationText"] then
			if EIDConfig["TransformationIcons"] and not(printTransformation(desc[2])=="Custom") then
				Isaac.RenderScaledText(printTransformation(desc[2]), EIDConfig["XPosition"]+16*EIDConfig["Scale"], temp-1,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["TransformationColor"][1] , EIDConfig["TransformationColor"][2], EIDConfig["TransformationColor"][3], EIDConfig["Transparency"])
			elseif not(transformations[desc[2]]) then --Custom transformationname
				Isaac.RenderScaledText(desc[2], EIDConfig["XPosition"]+16*EIDConfig["Scale"], temp-1,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["TransformationColor"][1] , EIDConfig["TransformationColor"][2], EIDConfig["TransformationColor"][3], EIDConfig["Transparency"])
			else
				Isaac.RenderScaledText(printTransformation(desc[2]), EIDConfig["XPosition"]+16*EIDConfig["Scale"], temp-1,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["TransformationColor"][1] , EIDConfig["TransformationColor"][2], EIDConfig["TransformationColor"][3], EIDConfig["Transparency"])
			end
		end
		if EIDConfig["TransformationIcons"] and not(printTransformation(desc[2])=="Custom") then
			IconSprite:Play(printTransformation(desc[2]))
			IconSprite.Scale = Vector(EIDConfig["Scale"],EIDConfig["Scale"])
			IconSprite:Update()
			IconSprite:Render(Vector(EIDConfig["XPosition"]+5*EIDConfig["Scale"],temp+5*EIDConfig["Scale"]), Vector(0,0), Vector(0,0))
		end
		temp = temp+10*EIDConfig["Scale"]
	end
	for line in string.gmatch(Description, '([^#]+)') do
		local array={}
		local text = ""
		for word in string.gmatch(line, '([^ ]+)') do
			if string.len(text)+string.len(word)<= tonumber(EIDConfig["TextboxWidth"]) then
				text = text.." "..word
			else
				table.insert(array, text)
				text = word
			end
		end
		table.insert(array, text)
		for i, v in ipairs(array) do
			if i== 1 then 
					Isaac.RenderScaledText("•"..v, EIDConfig["XPosition"], temp,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["TextColor"][1] , EIDConfig["TextColor"][2], EIDConfig["TextColor"][3], EIDConfig["Transparency"])
			else
					Isaac.RenderScaledText("  "..v, EIDConfig["XPosition"], temp,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["TextColor"][1] , EIDConfig["TextColor"][2], EIDConfig["TextColor"][3], EIDConfig["Transparency"])
			end
			temp = temp +10*EIDConfig["Scale"]
		end
	end
end

function printTrinketDescription(desc,typ)
	Description = desc[3]
	if type(desc[2])=="table" then
	    Description=desc[2][2]
	    desc[2]=desc[2][1]
	elseif desc[3]==nil then
	    Description=desc[2]
	    desc[2]=itemConfig:GetCollectible(desc[1]).Name
	end
	textboxWidth=tonumber(EIDConfig["TextboxWidth"])
	local temp = EIDConfig["YPosition"]

	if EIDConfig["ShowItemName"] then
		if typ=="trinket" then
		Isaac.RenderScaledText(desc[2], EIDConfig["XPosition"]+1*EIDConfig["Scale"], temp-4,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["ItemNameColor"][1] , EIDConfig["ItemNameColor"][2], EIDConfig["ItemNameColor"][3], EIDConfig["Transparency"])
		elseif typ=="card" then
		Isaac.RenderScaledText(desc[2], EIDConfig["XPosition"]+1*EIDConfig["Scale"], temp-4,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["ItemNameColor"][1] , EIDConfig["ItemNameColor"][2], EIDConfig["ItemNameColor"][3], EIDConfig["Transparency"])
		elseif typ=="pill" then
		Isaac.RenderScaledText(desc[2], EIDConfig["XPosition"]+1*EIDConfig["Scale"], temp-4,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["ItemNameColor"][1] , EIDConfig["ItemNameColor"][2], EIDConfig["ItemNameColor"][3], EIDConfig["Transparency"])
		elseif typ=="sacrifice" then
		Isaac.RenderScaledText(sacrificeDescriptionHeader, EIDConfig["XPosition"]+1*EIDConfig["Scale"], temp-4,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["ItemNameColor"][1] , EIDConfig["ItemNameColor"][2], EIDConfig["ItemNameColor"][3], EIDConfig["Transparency"])
		elseif typ=="custom" then
		Isaac.RenderScaledText(desc[2][1], EIDConfig["XPosition"]+1*EIDConfig["Scale"], temp-4,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["ItemNameColor"][1] , EIDConfig["ItemNameColor"][2], EIDConfig["ItemNameColor"][3], EIDConfig["Transparency"])
		Description= desc[2][2]
		end
		temp = temp+10*EIDConfig["Scale"]
	end
	for line in string.gmatch(Description, '([^#]+)') do
		local array={}
		local text = ""
		for word in string.gmatch(line, '([^ ]+)') do
			if string.len(text)+string.len(word)<=textboxWidth then
				text = text.." "..word
			else
				table.insert(array, text)
				text = word
			end
		end
		table.insert(array, text)
		for i, v in ipairs(array) do
			if i== 1 then 
					Isaac.RenderScaledText("•"..v, EIDConfig["XPosition"], temp,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["TextColor"][1] , EIDConfig["TextColor"][2], EIDConfig["TextColor"][3],  EIDConfig["Transparency"])
			else
					Isaac.RenderScaledText("  "..v, EIDConfig["XPosition"], temp,EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["TextColor"][1] , EIDConfig["TextColor"][2], EIDConfig["TextColor"][3],  EIDConfig["Transparency"])
			end
			temp = temp +10*EIDConfig["Scale"]
		end
	end
end

function printTransformation(S)
	local str="Custom";
	for i = 0, #transformations-1 do
		if (tonumber(S)==i) then
			str = tostring(transformations[i+1])
		end
	end
	return str
end

function HasCurseBlind()
	local num = Game():GetLevel():GetCurses()
    local t={}
    while num>0 do
        rest=num%2
        t[#t+1]=rest
        num=(num-rest)/2
    end
    
	return #t>6 and t[7]==1 
end

function renderQuestionMark() 
	IconSprite:Play("CurseOfBlind")
	IconSprite.Scale = Vector(EIDConfig["Scale"],EIDConfig["Scale"])
	IconSprite:Update()
	IconSprite:Render(Vector(EIDConfig["XPosition"]+5*EIDConfig["Scale"],EIDConfig["YPosition"]+5*EIDConfig["Scale"]), Vector(0,0), Vector(0,0))
end

local function onRender(t)

	local player = Isaac.GetPlayer(0)
	local closest = nil;
	local dist = 10000;
	for i, entity in ipairs(Isaac.GetRoomEntities()) do
		local isModEntityDesc = false
		if EIDConfig["EnableEntityDescriptions"] and (__eidEntityDescriptions[entity.Type.."."..entity.Variant.."."..entity.SubType]~=nil or type(entity:GetData()["EID_Description"]) ~= type(nil)) then 
			isModEntityDesc= true
		end
		if isModEntityDesc or (entity.Type == EntityType.ENTITY_PICKUP and (entity.Variant == PickupVariant.PICKUP_COLLECTIBLE or entity.Variant == PickupVariant.PICKUP_TRINKET or entity.Variant == PickupVariant.PICKUP_TAROTCARD or entity.Variant == PickupVariant.PICKUP_PILL) and entity.SubType>0) then
			local diff = entity.Position:__sub(player.Position);
			if diff:Length() < dist then
				closest = entity;
				dist = diff:Length();
			end  
		end
	end 
	
	if dist/40>tonumber(EIDConfig["MaxDistance"]) or not closest.Type == EntityType.ENTITY_PICKUP then
		if Game():GetRoom():GetType()==RoomType.ROOM_SACRIFICE and EIDConfig["DisplaySacrificeInfo"] then
			printTrinketDescription(sacrificeDescriptions[SacrificeCounter],"sacrifice")
		end
		return
	end
	
	if EIDConfig["Indicator"] == "blink" then
		local c = 255-math.floor(255*((closest.FrameCount%40)/40))
		closest:SetColor(Color(1,1,1,1,c,c,c),1,1,false,false)
		closest:Render(Vector(0,0))
		closest:SetColor(Color(1,1,1,1,0,0,0),2,1,false,false)
		
	elseif EIDConfig["Indicator"] == "border" then
		local c = 255-math.floor(255*((closest.FrameCount%40)/40))
		closest:SetColor(Color(1,1,1,1,c,c,c),1,1,false,false)
		closest:Render(Vector(0,1))
		closest:Render(Vector(0,-1))
		closest:Render(Vector(1,0))
		closest:Render(Vector(-1,0))
		closest:SetColor(Color(1,1,1,1,0,0,0),2,1,false,false)
		closest:Render(Vector(0,0))
		
	elseif EIDConfig["Indicator"] == "highlight" then
		closest:SetColor(Color(1,1,1,1,255,255,255),1,1,false,false)
		closest:Render(Vector(0,1))
		closest:Render(Vector(0,-1))
		closest:Render(Vector(1,0))
		closest:Render(Vector(-1,0))
		closest:SetColor(Color(1,1,1,1,0,0,0),2,1,false,false)
		closest:Render(Vector(0,0))
		
	elseif EIDConfig["Indicator"] == "arrow" then
		ArrowSprite:Update()
		local ArrowOffset = Vector(0,-35)
		if closest.Variant ==100 and not closest:ToPickup():IsShopItem() then ArrowOffset = Vector(0,-62) end
		ArrowSprite:Render(Game():GetRoom():WorldToScreenPosition(closest.Position+ArrowOffset), Vector(0,0), Vector(0,0))
	end

	if EIDConfig["EnableEntityDescriptions"] and type(closest:GetData()["EID_Description"]) ~= type(nil) then
		printTrinketDescription({closest.Type,closest:GetData()["EID_Description"]},"custom")
		return
	end
	
	if EIDConfig["EnableEntityDescriptions"] and __eidEntityDescriptions[closest.Type.."."..closest.Variant.."."..closest.SubType] ~=nil then
		printTrinketDescription({closest.Type,getModDescription(__eidEntityDescriptions,closest.Type.."."..closest.Variant.."."..closest.SubType)},"custom")
		return
	end
	
	if closest.Variant == PickupVariant.PICKUP_TRINKET then
		if closest.SubType <= 128 then
			printTrinketDescription(trinketdescriptions[closest.SubType],"trinket")
		elseif getModDescription(__eidTrinketDescriptions,closest.SubType) then
			printTrinketDescription({closest.SubType,getModDescription(__eidTrinketDescriptions,closest.SubType)},"trinket")
		else
			printTrinketDescription({closest.SubType,itemConfig:GetTrinket(closest.SubType).Description})
		end

	elseif closest.Variant == PickupVariant.PICKUP_COLLECTIBLE then
		if HasCurseBlind() and EIDConfig["DisableOnCurse"] then
			renderQuestionMark() 
			return
		end
		if getModDescription(__eidItemDescriptions,closest.SubType) then
			local tranformation = "0"
			if  getModDescription(__eidItemTransformations,closest.SubType) then
				 tranformation = getModDescription(__eidItemTransformations,closest.SubType)
			end 
			printDescription({closest.SubType,tranformation,getModDescription(__eidItemDescriptions,closest.SubType)})
		elseif closest.SubType <= 552 then
			if getModDescription(__eidItemTransformations,closest.SubType) then
				printDescription({closest.SubType,getModDescription(__eidItemTransformations,closest.SubType),descriptarray[closest.SubType][3]})
			else		
				printDescription(descriptarray[closest.SubType])
			end
		else
			printDescription({closest.SubType,"",itemConfig:GetCollectible(closest.SubType).Description})
		end

    elseif closest.Variant == PickupVariant.PICKUP_TAROTCARD then
		if EIDConfig["DisplayCardInfo"] then
			if closest:ToPickup():IsShopItem() and not EIDConfig["DisplayCardInfoShop"] then renderQuestionMark() return end
			
			if closest.SubType <= 54 then 
				printTrinketDescription(cardDescriptions[closest.SubType],"card")
				local sprite = Sprite()
				sprite:Load("gfx/cardfronts.anm2", true)
				sprite.Scale = Vector(EIDConfig["Scale"],EIDConfig["Scale"])
				sprite:Play(tostring(closest.SubType))
				sprite:Update()
				local offsetX = 0
				if EIDConfig["ShowItemName"] then offsetX = 10 end
				
				sprite:Render(Vector(EIDConfig["XPosition"]-10,EIDConfig["YPosition"]+(12+offsetX)*EIDConfig["Scale"]), Vector(0,0), Vector(0,0))
			elseif getModDescription(__eidCardDescriptions,closest.SubType) then
				printTrinketDescription({closest.SubType,getModDescription(__eidCardDescriptions,closest.SubType)},"card")
			else
				printTrinketDescription({closest.SubType,itemConfig:GetCard(closest.SubType).Description})
			end
		end

    elseif closest.Variant == PickupVariant.PICKUP_PILL then
		if EIDConfig["DisplayPillInfo"] then
			if closest:ToPickup():IsShopItem() and not EIDConfig["DisplayPillInfoShop"] then renderQuestionMark() return end
			
			local pillColor = closest.SubType
			local pool = Game():GetItemPool()
			local pillEffect = pool:GetPillEffect(pillColor)
			local identified = pool:IsPillIdentified(pillColor)
			if (identified or EIDConfig["ShowUnidentifiedPillDescriptions"]) then
				if getModDescription(__eidPillDescriptions,pillEffect) then
					printTrinketDescription({pillEffect,getModDescription(__eidPillDescriptions,pillEffect)},"pill")
				elseif pillEffect < 47 then 
					printTrinketDescription(pillDescriptions[pillEffect+1],"pill")
				else  
					Isaac.RenderScaledText(EIDConfig["ErrorMessage"], EIDConfig["XPosition"], EIDConfig["YPosition"],EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["ErrorColor"][1] , EIDConfig["ErrorColor"][2], EIDConfig["ErrorColor"][3], EIDConfig["Transparency"])
				end
			else
				Isaac.RenderScaledText(unidentifiedPillMessage, EIDConfig["XPosition"], EIDConfig["YPosition"],EIDConfig["Scale"],EIDConfig["Scale"], EIDConfig["ErrorColor"][1] , EIDConfig["ErrorColor"][2], EIDConfig["ErrorColor"][3], EIDConfig["Transparency"])
			end
			local pillsprite = closest:GetSprite()
			pillsprite.Scale = Vector(EIDConfig["Scale"]*0.75,EIDConfig["Scale"]*0.75)
			if EIDConfig["Indicator"] == "blink" then
				closest:SetColor(Color(1,1,1,1,0,0,0),0,0,false,false)
			end
			pillsprite:Update()
			local offsetX = 0
			if EIDConfig["ShowItemName"] and (identified or EIDConfig["ShowUnidentifiedPillDescriptions"]) then offsetX = 10 end
			pillsprite:Render(Vector(EIDConfig["XPosition"]-10*EIDConfig["Scale"],EIDConfig["YPosition"]+(11+offsetX)*EIDConfig["Scale"]), Vector(0,0), Vector(0,0))
			pillsprite.Scale = Vector(1,1)
			if EIDConfig["Indicator"] == "blink" then
				local c = 255-math.floor(255*((closest.FrameCount%40)/40))
				closest:SetColor(Color(1,1,1,1,c,c,c),0,0,false,false)
			end
		end
    end
end

EID:AddCallback(ModCallbacks.MC_POST_RENDER, onRender)

